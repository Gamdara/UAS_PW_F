<?php echo e($slot); ?>

<?php /**PATH C:\Users\slazr\Downloads\Compressed\UAS_PW_F-master\api\vendor\laravel\framework\src\Illuminate\Mail/resources/views/text/footer.blade.php ENDPATH**/ ?>