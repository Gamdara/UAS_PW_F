<?php echo e($slot); ?>: <?php echo e($url); ?>

<?php /**PATH D:\xampp\htdocs\UAS PW ver 2\UAS_PW_F\api\vendor\laravel\framework\src\Illuminate\Mail/resources/views/text/button.blade.php ENDPATH**/ ?>