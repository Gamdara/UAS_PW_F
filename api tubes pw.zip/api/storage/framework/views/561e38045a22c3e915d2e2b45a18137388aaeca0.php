<?php echo e($slot); ?>

<?php /**PATH D:\xampp\htdocs\UAS PW ver 2\UAS_PW_F\api\vendor\laravel\framework\src\Illuminate\Mail/resources/views/text/footer.blade.php ENDPATH**/ ?>